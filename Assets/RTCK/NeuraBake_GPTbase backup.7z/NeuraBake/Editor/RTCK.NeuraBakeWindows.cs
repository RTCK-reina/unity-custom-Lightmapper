using RTCK.NeuraBake.Runtime;  // Runtime�̐ݒ�N���X���Q��
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace RTCK.NeuraBake.Editor
{
    public class NeuraBakeWindow : EditorWindow
    {
        private NeuraBakeSettings settings = new NeuraBakeSettings();
        private string settingsFilePath = "Assets/RTCK_NeuraBake/Settings/default.json";
        private Vector2 scrollPosition;

        [MenuItem("RTCK/NeuraBake")]
        public static void ShowWindow()
        {
            var window = GetWindow<NeuraBakeWindow>("NeuraBake");
            window.minSize = new Vector2(320, 400);
        }

        private void OnGUI()
        {
            using (var scrollView = new EditorGUILayout.ScrollViewScope(scrollPosition))
            {
                scrollPosition = scrollView.scrollPosition;

                GUILayout.Label("RTCK NeuraBake �ݒ�", EditorStyles.boldLabel);

                EditorGUI.BeginChangeCheck();

                settings.resolution = EditorGUILayout.FloatField("Lightmap �𑜓x", settings.resolution);
                settings.sampleCount = EditorGUILayout.IntField("�T���v����", settings.sampleCount);
                settings.bounceCount = EditorGUILayout.IntSlider("�o�E���X��", settings.bounceCount, 1, 10);
                settings.useAmbientOcclusion = EditorGUILayout.Toggle("Ambient Occlusion", settings.useAmbientOcclusion);
                settings.directional = EditorGUILayout.Toggle("Directional Lightmap", settings.directional);
                settings.useDenoiser = EditorGUILayout.Toggle("Denoiser �L����", settings.useDenoiser);
                settings.atlasSize = EditorGUILayout.IntPopup("Atlas �T�C�Y", settings.atlasSize,
                    new string[] { "512", "1024", "2048", "4096" },
                    new int[] { 512, 1024, 2048, 4096 });

                if (EditorGUI.EndChangeCheck())
                {
                    var (isValid, message) = settings.Validate();
                    if (!isValid)
                    {
                        EditorGUILayout.HelpBox(message, MessageType.Warning);
                    }
                }

                GUILayout.Space(20);

                DrawSettingsButtons();

                GUILayout.Space(10);

                EditorGUILayout.LabelField("���݂̐ݒ�t�@�C��:",
                    string.IsNullOrEmpty(settingsFilePath) ? "�Ȃ�" : Path.GetFileName(settingsFilePath));

                if (GUILayout.Button("Bake ���s"))
                {
                    RunBake();
                }
            }
        }

        private void DrawSettingsButtons()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("�ݒ��ۑ�")) SaveSettings();
                if (GUILayout.Button("�ʖ��ŕۑ�")) SaveSettingsAs();
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("�ݒ��ǂݍ���")) LoadSettings();
                if (GUILayout.Button("�ʃt�@�C�����J��")) LoadSettingsFrom();
            }

            if (GUILayout.Button("�ݒ�����Z�b�g"))
            {
                if (EditorUtility.DisplayDialog("�ݒ�̃��Z�b�g",
                    "�S�Ă̐ݒ�������l�ɖ߂��܂����H", "�͂�", "������"))
                {
                    settings.Reset();
                }
            }
        }

        private void SaveSettings()
        {
            try
            {
                string json = JsonUtility.ToJson(settings, true);
                File.WriteAllText(settingsFilePath, json);
                Debug.Log($"�ݒ��ۑ����܂���: {settingsFilePath}");
            }
            catch (Exception e)
            {
                Debug.LogError($"�ݒ�̕ۑ��Ɏ��s���܂���: {e.Message}");
            }
        }

        private void SaveSettingsAs()
        {
            string path = EditorUtility.SaveFilePanel("�ݒ��ۑ�",
                Application.dataPath, "default", "json");
            if (!string.IsNullOrEmpty(path))
            {
                settingsFilePath = path;
                SaveSettings();
            }
        }

        private void LoadSettings()
        {
            try
            {
                if (File.Exists(settingsFilePath))
                {
                    string json = File.ReadAllText(settingsFilePath);
                    var loadedSettings = JsonUtility.FromJson<NeuraBakeSettings>(json);
                    if (loadedSettings != null)
                    {
                        settings = loadedSettings;
                        Debug.Log($"�ݒ��ǂݍ��݂܂���: {settingsFilePath}");
                    }
                    else
                    {
                        Debug.LogWarning("�ݒ�t�@�C���̓��e���s���ł��B");
                    }
                }
                else
                {
                    Debug.LogWarning($"�ݒ�t�@�C�������݂��܂���: {settingsFilePath}");
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"�ݒ�̓ǂݍ��݂Ɏ��s���܂���: {e.Message}");
            }
        }

        private void LoadSettingsFrom()
        {
            string path = EditorUtility.OpenFilePanel("�ݒ��ǂݍ���",
                Application.dataPath, "json");
            if (!string.IsNullOrEmpty(path))
            {
                settingsFilePath = path;
                LoadSettings();
            }
        }

        private void RunBake()
        {
            Debug.Log("Bake ���s�����͖������ł��B");
        }
    }
}
