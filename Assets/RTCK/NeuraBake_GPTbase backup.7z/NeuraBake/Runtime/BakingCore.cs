using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Threading;
using System.Linq;
using System; // IProgress<T> ���g�p���邽�߂ɒǉ�

namespace RTCK.NeuraBake.Runtime
{
    public class BakingCore
    {       
        private NeuraBakeSettings settings;
        private int samplesPerPixel;
        private Light[] _cachedLights;
        private Dictionary<Material, (Color baseColor, float metallic, float roughness)> _materialCache 
            = new Dictionary<Material, (Color, float, float)>();

        private class MeshCache
        {
            public Vector2[] uvs;
            public Vector3[] vertices;
            public Vector3[] normals;
            public int[] triangles;
            public Dictionary<Vector2, (Vector3 position, Vector3 normal)> uvLookup 
                = new Dictionary<Vector2, (Vector3 position, Vector3 normal)>();
        }

        private Dictionary<Mesh, MeshCache> _meshCache = new Dictionary<Mesh, MeshCache>();

        private MeshCache GetMeshCache(Mesh mesh)
        {
            if (!_meshCache.TryGetValue(mesh, out var cache))
            {
                cache = new MeshCache
                {
                    uvs = mesh.uv,
                    vertices = mesh.vertices,
                    normals = mesh.normals,
                    triangles = mesh.triangles
                };
                _meshCache[mesh] = cache;
            }
            return cache;
        }

        private class RaycastCache
        {
            public Dictionary<(Vector3 origin, Vector3 direction), RaycastHit> cache 
                = new Dictionary<(Vector3 origin, Vector3 direction), RaycastHit>();
        }

        private RaycastCache _raycastCache = new RaycastCache();
        private Dictionary<Vector2, (Vector3 position, Vector3 normal)> _uvCache
            = new Dictionary<Vector2, (Vector3 position, Vector3 normal)>();

        private bool CachedRaycast(Ray ray, float maxDistance, out RaycastHit hitInfo)
        {
            Vector3 roundedOrigin = new Vector3(
                Mathf.Round(ray.origin.x * 1000f) / 1000f,
                Mathf.Round(ray.origin.y * 1000f) / 1000f,
                Mathf.Round(ray.origin.z * 1000f) / 1000f
            );
            Vector3 roundedDir = new Vector3(
                Mathf.Round(ray.direction.x * 1000f) / 1000f,
                Mathf.Round(ray.direction.y * 1000f) / 1000f,
                Mathf.Round(ray.direction.z * 1000f) / 1000f
            );
            var key = (roundedOrigin, roundedDir);

            if (_raycastCache.cache.TryGetValue(key, out hitInfo))
                return true;

            if (Physics.Raycast(ray, out hitInfo, maxDistance))
            {
                _raycastCache.cache[key] = hitInfo;
                return true;
            }
            return false;
        }

        private (Vector3Int, Vector3Int) ToCacheKey(Vector3 origin, Vector3 dir, float precision = 1000f)
        {
            Vector3Int o = new Vector3Int(
                Mathf.RoundToInt(origin.x * precision),
                Mathf.RoundToInt(origin.y * precision),
                Mathf.RoundToInt(origin.z * precision)
            );
            Vector3Int d = new Vector3Int(
                Mathf.RoundToInt(dir.x * precision),
                Mathf.RoundToInt(dir.y * precision),
                Mathf.RoundToInt(dir.z * precision)
            );
            return (o, d);
        }

        public BakingCore(NeuraBakeSettings bakeSettings)
        {
            settings = bakeSettings;
            samplesPerPixel = Mathf.Max(1, settings.sampleCount); // 1�����ɂȂ�Ȃ��悤��
            _cachedLights = GameObject.FindObjectsOfType<Light>();
        }

        private void CacheLights()
        {
            _cachedLights = GameObject.FindObjectsOfType<Light>();
        }

        public void ClearCaches()
        {
            lock (_cacheLock)
            {
                _materialCache.Clear();
                _meshCache.Clear();
                _raycastCache.cache.Clear();
                _uvCache.Clear();
                _materialPropsCache.Clear();
            }
            System.GC.Collect();
        }

        private void CleanupCaches()
        {
            if (_raycastCache.cache.Count > 10000)
                _raycastCache.cache.Clear();
        }

        public void OptimizeForSettings()
        {
            var maxCacheEntries = Mathf.CeilToInt(settings.resolution * settings.resolution * 0.1f);
            if (_raycastCache.cache.Count > maxCacheEntries)
            {
                _raycastCache.cache.Clear();
            }
            
            int threadCount = Mathf.Clamp(settings.sampleCount / 32, 1, System.Environment.ProcessorCount);
            System.Threading.ThreadPool.SetMinThreads(threadCount, threadCount);
        }

        private (Color baseColor, float metallic, float roughness) GetBasicMaterialProperties(Material material)
        {
            if (_materialCache.TryGetValue(material, out var cached))
                return cached;

            var props = (
                baseColor: material.HasProperty("_BaseColor") ? material.GetColor("_BaseColor") : Color.white,
                metallic: material.HasProperty("_Metallic") ? material.GetFloat("_Metallic") : 0f,
                roughness: material.HasProperty("_Glossiness") ? 1f - material.GetFloat("_Glossiness") : 1f
            );

            _materialCache[material] = props;
            return props;
        }

        private class MaterialProperties
        {
            public Color baseColor;
            public float metallic;
            public float roughness;
            public Texture2D metallicGlossMap;
            public float smoothness;
            public Vector2 uvScale = Vector2.one;
            public Vector2 uvOffset = Vector2.zero;
        }

        private Dictionary<Material, MaterialProperties> _materialPropsCache 
            = new Dictionary<Material, MaterialProperties>();

        private readonly object _cacheLock = new object();

        private MaterialProperties GetMaterialProperties(Material material)
        {
            lock (_cacheLock)
            {
                if (_materialPropsCache.TryGetValue(material, out var cached))
                    return cached;

                bool hasBaseColor = material.HasProperty("_BaseColor");
                bool hasMetallic = material.HasProperty("_Metallic");
                bool hasSmoothness = material.HasProperty("_Smoothness");
                bool hasMetallicGlossMap = material.HasProperty("_MetallicGlossMap");
                var st = material.HasProperty("_MainTex_ST") 
                    ? material.GetVector("_MainTex_ST") 
                    : new Vector4(1, 1, 0, 0);

                var props = new MaterialProperties
                {
                    baseColor = hasBaseColor ? material.GetColor("_BaseColor") : Color.white,
                    metallic = hasMetallic ? material.GetFloat("_Metallic") : 0f,
                    smoothness = hasSmoothness ? material.GetFloat("_Smoothness") : 0.5f,
                    metallicGlossMap = hasMetallicGlossMap 
                        ? material.GetTexture("_MetallicGlossMap") as Texture2D 
                        : null,
                    roughness = 1f - (hasSmoothness ? material.GetFloat("_Smoothness") : 0.5f),
                    uvScale = new Vector2(st.x, st.y),
                    uvOffset = new Vector2(st.z, st.w)
                };

                _materialPropsCache[material] = props;
                return props;
            }
        }

        private Color SafeSample(Texture2D tex, Vector2 uv, Color fallback)
        {
            if (tex == null) return fallback;
            if (!tex.isReadable)
            {
                Debug.LogWarning($"Texture {tex.name} is not readable. Using fallback color.");
                return fallback;
            }
            
            try 
            {
                return tex.GetPixelBilinear(
                    Mathf.Repeat(uv.x, 1f), 
                    Mathf.Repeat(uv.y, 1f)
                );
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Error sampling texture {tex.name}: {e.Message}");
                return fallback;
            }
        }

        private (float metallic, float roughness) SampleMaterialTextures(MaterialProperties props, Vector2 uv)
        {
            Vector2 transformedUV = new Vector2(
                uv.x * props.uvScale.x + props.uvOffset.x,
                uv.y * props.uvScale.y + props.uvOffset.y
            );

            float metallic = props.metallic;
            float roughness = props.roughness;

            if (props.metallicGlossMap != null)
            {
                Color sample = SafeSample(props.metallicGlossMap, transformedUV, new Color(0, 0, 0, 1));
                bool isMaskMap = false;
                if (props.metallicGlossMap.name.Contains("HDRP"))
                    isMaskMap = true;
                else if (props.metallicGlossMap.name.Contains("_MaskMap"))
                    isMaskMap = true;

                if (isMaskMap ||
                    (props.baseColor != null && props.baseColor.a == 1.0f && props.metallicGlossMap.width == props.metallicGlossMap.height && props.metallicGlossMap.format == TextureFormat.RGBA32))
                {
                    metallic = sample.a;
                    roughness = sample.r;
                }
                else
                {
                    metallic *= sample.r;
                    roughness = 1.0f - sample.a;
                }
            }

            return (metallic, roughness);
        }

        private Color CalculateLighting(Vector3 position, Vector3 normal, Material material, Vector2 uv)
        {
            var props = GetMaterialProperties(material);
            var (sampledMetallic, sampledRoughness) = SampleMaterialTextures(props, uv);

            Vector3 viewDir = Vector3.one.normalized;
            Color finalColor = RenderSettings.ambientLight * props.baseColor;

            float alpha = sampledRoughness * sampledRoughness;
            float alpha2 = alpha * alpha;
            Color F0 = Color.Lerp(new Color(0.04f, 0.04f, 0.04f), props.baseColor, sampledMetallic);
            float k = alpha / 2.0f;

            foreach (var light in _cachedLights)
            {
                Vector3 lightPos = light.transform.position;
                Vector3 lightDir = (lightPos - position).normalized;
                Vector3 halfDir = (viewDir + lightDir).normalized;

                float NdotL = Mathf.Max(Vector3.Dot(normal, lightDir), 0.0f);
                float NdotV = Mathf.Max(Vector3.Dot(normal, viewDir), 0.0f);
                float NdotH = Mathf.Max(Vector3.Dot(normal, halfDir), 0.0f);
                float VdotH = Mathf.Max(Vector3.Dot(viewDir, halfDir), 0.0f);

                if (NdotL <= 0.0f || NdotV <= 0.0f)
                    continue;

                float lightRange = light.range;
                if (Physics.Raycast(position, lightDir, out RaycastHit shadowHit, lightRange))
                {
                    // �Օ�����Ă���ꍇ�̓X�L�b�v
                    continue;
                }

                Color lightContribution = CalculatePBRLighting(
                    NdotL, NdotV, NdotH, VdotH,
                    alpha2, k, F0, props.baseColor, sampledMetallic,
                    light.color * light.intensity
                );

                switch (light.type)
                {
                    case LightType.Point:
                        float dist = Vector3.Distance(position, light.transform.position);
                        float atten = 1.0f / Mathf.Max(0.01f, dist * dist);
                        lightContribution *= atten;
                        break;
                    case LightType.Spot:
                        // �X�|�b�g�p�x�␳�E����
                        break;
                    case LightType.Directional:
                        // �����Ȃ�
                        break;
                }

                finalColor += lightContribution;
            }

            ApplyAOAndBounce(ref finalColor, position, normal, material);

            if (QualitySettings.activeColorSpace == ColorSpace.Gamma)
                finalColor = finalColor.gamma;
            else
                finalColor = finalColor.linear;

            if (samplesPerPixel > 0)
                finalColor *= (1.0f / samplesPerPixel);

            return finalColor;
        }

        private Color CalculatePBRLighting(
            float NdotL, float NdotV, float NdotH, float VdotH,
            float alpha2, float k, Color F0, Color baseColor, float metallic, Color lightColor
        )
        {
            if (NdotL <= 0.0f || NdotV <= 0.0f)
                return Color.black;

            float fresnelPower = Mathf.Pow(1.0f - VdotH, 5.0f);
            Color F = F0 + (Color.white - F0) * fresnelPower;

            float nl_k = NdotL * (1.0f - k) + k;
            float nv_k = NdotV * (1.0f - k) + k;
            float G = (NdotL * NdotV) / (nl_k * nv_k);

            float NH2 = NdotH * NdotH;
            float denom = NH2 * (alpha2 - 1.0f) + 1.0f;
            float D = alpha2 / (Mathf.PI * denom * denom);

            Color specular = (F * G * D) / (4.0f * NdotL * NdotV + 0.001f);
            Color diffuse = (1.0f - metallic) * baseColor / Mathf.PI;

            return lightColor * (diffuse + specular) * NdotL;
        }

        private void ApplyAOAndBounce(ref Color finalColor, Vector3 position, Vector3 normal, Material material)
        {
            finalColor *= Mathf.Clamp01(Vector3.Dot(normal, Vector3.up));

            for (int i = 0; i < settings.aoSampleCount; i++)
            {
                // �����_��������Raycast���A�Օ������v�Z
            }

            finalColor += RenderSettings.ambientLight * 0.5f * material.color;
        }

        private Vector3 GetCachedPosition(Vector2 uv)
        {
            if (_uvCache.TryGetValue(uv, out var cached))
            {
                return cached.position;
            }
            return Vector3.zero;
        }

        private void ApplyLightingEffects(ref Color finalColor, Vector3 position, Vector3 normal, Material material)
        {

            ApplyAOAndBounce(ref finalColor, position, normal, material);
        }

        public async Task<Texture2D> BakeLightmapAsync(CancellationToken token = default, IProgress<float> progress = null)
        {
            int resolution = Mathf.RoundToInt(settings.resolution);
            Texture2D lightmap = new Texture2D(resolution, resolution, TextureFormat.RGBAHalf, false);
            lightmap.wrapMode = TextureWrapMode.Clamp;

            var renderers = GameObject.FindObjectsOfType<MeshRenderer>();
            Color[] lightmapPixels = new Color[resolution * resolution];

            // 1. UV��Renderer/�O�p�`�C���f�b�N�X�̎��O�}�b�s���O
            var uvToInfo = new Dictionary<Vector2Int, (MeshRenderer renderer, Mesh mesh, int triIdx, Vector3 bary)>();
            foreach (var renderer in renderers)
            {
                Mesh mesh = renderer.GetComponent<MeshFilter>()?.sharedMesh;
                if (mesh == null || mesh.uv == null || mesh.uv.Length == 0) continue;
                var cache = GetMeshCache(mesh);

                for (int tri = 0; tri < mesh.triangles.Length; tri += 3)
                {
                    int i0 = mesh.triangles[tri];
                    int i1 = mesh.triangles[tri + 1];
                    int i2 = mesh.triangles[tri + 2];
                    Vector2 uv0 = cache.uvs[i0];
                    Vector2 uv1 = cache.uvs[i1];
                    Vector2 uv2 = cache.uvs[i2];

                    // �O�p�`�̃o�E���f�B���O�{�b�N�X���̃s�N�Z���𑖍�
                    Vector2 min = Vector2.Min(Vector2.Min(uv0, uv1), uv2);
                    Vector2 max = Vector2.Max(Vector2.Max(uv0, uv1), uv2);
                    int minX = Mathf.Clamp(Mathf.FloorToInt(min.x * resolution), 0, resolution - 1);
                    int minY = Mathf.Clamp(Mathf.FloorToInt(min.y * resolution), 0, resolution - 1);
                    int maxX = Mathf.Clamp(Mathf.CeilToInt(max.x * resolution), 0, resolution - 1);
                    int maxY = Mathf.Clamp(Mathf.CeilToInt(max.y * resolution), 0, resolution - 1);

                    for (int y = minY; y <= maxY; y++)
                    {
                        for (int x = minX; x <= maxX; x++)
                        {
                            Vector2 uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                            // �o���Z���^�[�v�Z
                            Vector3 bary = Barycentric(uv0, uv1, uv2, uv);
                            if (bary.x < -0.001f || bary.y < -0.001f || bary.z < -0.001f) continue; // �O�p�`�O

                            uvToInfo[new Vector2Int(x, y)] = (renderer, mesh, tri, bary);
                        }
                    }
                }
            }

            int totalPixels = resolution * resolution;
            int batchSize = 128;

            for (int i = 0; i < totalPixels; i += batchSize)
            {
                token.ThrowIfCancellationRequested();
                int count = Mathf.Min(batchSize, totalPixels - i);

                await Task.Run(() =>
                {
                    for (int j = 0; j < count; j++)
                    {
                        int index = i + j;
                        int x = index % resolution;
                        int y = index / resolution;
                        var key = new Vector2Int(x, y);

                        if (!uvToInfo.TryGetValue(key, out var info))
                        {
                            lightmapPixels[index] = Color.black;
                            continue;
                        }

                        var (renderer, mesh, triIdx, bary) = info;
                        var cache = GetMeshCache(mesh);
                        int i0 = mesh.triangles[triIdx];
                        int i1 = mesh.triangles[triIdx + 1];
                        int i2 = mesh.triangles[triIdx + 2];

                        // �o���Z���^�[��Ԃō����x�ȃ��[���h���W�E�@���擾
                        Vector3 pos = renderer.transform.TransformPoint(
                            cache.vertices[i0] * bary.x + cache.vertices[i1] * bary.y + cache.vertices[i2] * bary.z
                        );
                        Vector3 normal = renderer.transform.TransformDirection(
                            cache.normals[i0] * bary.x + cache.normals[i1] * bary.y + cache.normals[i2] * bary.z
                        ).normalized;
                        Vector2 uv = cache.uvs[i0] * bary.x + cache.uvs[i1] * bary.y + cache.uvs[i2] * bary.z;

                        Material mat = renderer.sharedMaterial;
                        Color col = CalculateLighting(pos, normal, mat, uv);
                        lightmapPixels[index] = col;
                    }
                });

                if (progress != null)
                    progress.Report((float)i / totalPixels);
            }

            lightmap.SetPixels(lightmapPixels);
            lightmap.Apply();
            return lightmap;
        }

        // �o���Z���^�[���W�v�Z�iUV��ԁj
        private Vector3 Barycentric(Vector2 a, Vector2 b, Vector2 c, Vector2 p)
        {
            Vector2 v0 = b - a, v1 = c - a, v2 = p - a;
            float d00 = Vector2.Dot(v0, v0);
            float d01 = Vector2.Dot(v0, v1);
            float d11 = Vector2.Dot(v1, v1);
            float d20 = Vector2.Dot(v2, v0);
            float d21 = Vector2.Dot(v2, v1);
            float denom = d00 * d11 - d01 * d01;
            if (Mathf.Abs(denom) < 1e-6f) return new Vector3(-1, -1, -1); // �ޔ�l
            float v = (d11 * d20 - d01 * d21) / denom;
            float w = (d00 * d21 - d01 * d20) / denom;
            float u = 1.0f - v - w;
            return new Vector3(u, v, w);
        }
        public Texture2D BakeToTexture(MeshRenderer renderer)
        {
            Mesh mesh = renderer.GetComponent<MeshFilter>()?.sharedMesh;
            if (mesh == null || mesh.uv == null || mesh.uv.Length == 0)
                return null;

            int resolution = Mathf.RoundToInt(settings.resolution);
            Texture2D tex = new Texture2D(resolution, resolution, TextureFormat.RGBAHalf, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[resolution * resolution];

            var cache = GetMeshCache(mesh);
            Material mat = renderer.sharedMaterial;

            // UV���O�p�`�C���f�b�N�X�̎��O�}�b�s���O
            var uvToTri = new Dictionary<Vector2Int, (int triIdx, Vector3 bary)>();
            for (int tri = 0; tri < mesh.triangles.Length; tri += 3)
            {
                int i0 = mesh.triangles[tri];
                int i1 = mesh.triangles[tri + 1];
                int i2 = mesh.triangles[tri + 2];
                Vector2 uv0 = cache.uvs[i0];
                Vector2 uv1 = cache.uvs[i1];
                Vector2 uv2 = cache.uvs[i2];

                Vector2 min = Vector2.Min(Vector2.Min(uv0, uv1), uv2);
                Vector2 max = Vector2.Max(Vector2.Max(uv0, uv1), uv2);
                int minX = Mathf.Clamp(Mathf.FloorToInt(min.x * resolution), 0, resolution - 1);
                int minY = Mathf.Clamp(Mathf.FloorToInt(min.y * resolution), 0, resolution - 1);
                int maxX = Mathf.Clamp(Mathf.CeilToInt(max.x * resolution), 0, resolution - 1);
                int maxY = Mathf.Clamp(Mathf.CeilToInt(max.y * resolution), 0, resolution - 1);

                for (int y = minY; y <= maxY; y++)
                {
                    for (int x = minX; x <= maxX; x++)
                    {
                        Vector2 uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                        Vector3 bary = Barycentric(uv0, uv1, uv2, uv);
                        if (bary.x < -0.001f || bary.y < -0.001f || bary.z < -0.001f) continue;
                        uvToTri[new Vector2Int(x, y)] = (tri, bary);
                    }
                }
            }

            for (int y = 0; y < resolution; y++)
            {
                for (int x = 0; x < resolution; x++)
                {
                    int idx = y * resolution + x;
                    var key = new Vector2Int(x, y);
                    if (!uvToTri.TryGetValue(key, out var info))
                    {
                        pixels[idx] = Color.black;
                        continue;
                    }
                    int triIdx = info.triIdx;
                    Vector3 bary = info.bary;
                    int i0 = mesh.triangles[triIdx];
                    int i1 = mesh.triangles[triIdx + 1];
                    int i2 = mesh.triangles[triIdx + 2];
                    Vector3 pos = renderer.transform.TransformPoint(
                        cache.vertices[i0] * bary.x + cache.vertices[i1] * bary.y + cache.vertices[i2] * bary.z
                    );
                    Vector3 normal = renderer.transform.TransformDirection(
                        cache.normals[i0] * bary.x + cache.normals[i1] * bary.y + cache.normals[i2] * bary.z
                    ).normalized;
                    Vector2 uv = cache.uvs[i0] * bary.x + cache.uvs[i1] * bary.y + cache.uvs[i2] * bary.z;
                    Color col = CalculateLighting(pos, normal, mat, uv);
                    pixels[idx] = col;
                }
            }
            tex.SetPixels(pixels);
            tex.Apply();
            return tex;
        }

        // RenderTexture ���� Texture2D �֕ϊ����郁�\�b�h
        public static Texture2D ConvertRenderTextureToTexture2D(RenderTexture rt)
        {
            if (rt == null)
            {
                Debug.LogError("RenderTexture is null");
                return null;
            }

            var currentRT = RenderTexture.active;
            try
            {
                RenderTexture.active = rt;
                Texture2D tex = new Texture2D(rt.width, rt.height, TextureFormat.RGBA32, false);
                tex.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0);
                tex.Apply();
                return tex;
            }
            catch (Exception e)
            {
                Debug.LogError($"Error converting RenderTexture to Texture2D: {e.Message}");
                return null;
            }
            finally
            {
                RenderTexture.active = currentRT;
            }
        }

        // Texture2D �� PNG �t�@�C���Ƃ��ĕۑ����郁�\�b�h
        public static bool SaveTexture2DToPNG(Texture2D tex, string path)
        {
            if (tex == null)
            {
                Debug.LogError("Texture2D is null");
                return false;
            }

            try
            {
                byte[] pngData = tex.EncodeToPNG();
                if (pngData == null)
                {
                    Debug.LogError("Failed to encode texture to PNG");
                    return false;
                }

                File.WriteAllBytes(path, pngData);
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"Error saving PNG file: {e.Message}");
                return false;
            }
        }
    }

    // NeuraBakeSettings �N���X�� aoSampleCount �v���p�e�B��ǉ�
    public class NeuraBakeSettings
    {
        public int aoSampleCount { get; set; } = 16; // �f�t�H���g�l��ݒ�
        // �����̃v���p�e�B�⃁�\�b�h�͂��̂܂�
    }
}
